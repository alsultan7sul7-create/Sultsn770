# 🎓 Student Performance Prediction System
## نظام توقع أداء الطلاب باستخدام الذكاء الاصطناعي

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template)
[![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)](https://python.org)
[![Flask](https://img.shields.io/badge/Flask-2.3.3-green.svg)](https://flask.palletsprojects.com)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## 🌟 نظرة عامة

نظام ذكي متطور لتوقع الأداء الأكاديمي للطلاب باستخدام خوارزميات التعلم الآلي، مع واجهة ويب احترافية تدعم اللغة العربية بالكامل.

### 🎯 المميزات الرئيسية
- **🧠 ذكاء اصطناعي متقدم** بدقة 98.90%
- **🎨 واجهة احترافية** مع 9 صفحات كاملة
- **📱 تصميم متجاوب** يعمل على جميع الأجهزة
- **🔒 أمان متقدم** مع تشفير البيانات
- **📊 تحليلات شاملة** مع رسوم بيانية تفاعلية
- **🌐 دعم كامل للعربية** مع RTL

## 🚀 النشر السريع

### Heroku (الأسرع)
```bash
heroku create student-performance-ai
git push heroku main
heroku open
```

### Railway (مجاني)
1. اذهب إلى [Railway.app](https://railway.app)
2. اختر "Deploy from GitHub"
3. سيتم النشر تلقائياً!

### تشغيل محلي
```bash
pip install -r requirements.txt
python flask_app_enhanced.py
```

## 🧠 نموذج الذكاء الاصطناعي

### الخوارزمية
- **النوع**: Linear Regression
- **الدقة**: 98.90% (R² Score)
- **خطأ RMSE**: 2.02
- **عدد العينات**: 10,000 طالب

### المتغيرات المؤثرة
1. **ساعات الدراسة اليومية** (الأكثر تأثيراً)
2. **الدرجات السابقة**
3. **الأنشطة اللامنهجية**
4. **ساعات النوم**
5. **عدد أوراق الأسئلة المُمارسة**

## 🎨 لقطات الشاشة

### الصفحة الرئيسية
![الصفحة الرئيسية](assets/screenshots/homepage.png)

### لوحة التحكم
![لوحة التحكم](assets/screenshots/dashboard.png)

### الإحصائيات
![الإحصائيات](assets/screenshots/statistics.png)

## 🔧 التقنيات المستخدمة

### Backend
- **Flask 2.3.3** - إطار العمل الرئيسي
- **scikit-learn 1.3.0** - التعلم الآلي
- **pandas 2.1.1** - معالجة البيانات
- **SQLite** - قاعدة البيانات

### Frontend
- **HTML5/CSS3** - الهيكل والتصميم
- **JavaScript ES6+** - التفاعل
- **Bootstrap 5** - التخطيط المتجاوب
- **Chart.js** - الرسوم البيانية

## 📊 الإحصائيات والنتائج

### أداء النموذج
- **دقة التدريب**: 98.87%
- **دقة الاختبار**: 98.90%
- **خطأ متوسط**: 2.02 نقطة
- **وقت الاستجابة**: < 0.1 ثانية

### توزيع مستويات الأداء
- **ممتاز (90-100)**: 15%
- **جيد جداً (80-89)**: 25%
- **جيد (70-79)**: 30%
- **مقبول (60-69)**: 20%
- **ضعيف (أقل من 60)**: 10%

## 🚀 التطوير والمساهمة

### متطلبات التطوير
```bash
Python 3.9+
Flask 2.3.3+
scikit-learn 1.3.0+
```

### إعداد بيئة التطوير
```bash
# استنساخ المشروع
git clone https://github.com/your-username/student-performance-prediction

# الانتقال للمجلد
cd student-performance-prediction

# تثبيت المتطلبات
pip install -r requirements.txt

# تشغيل التطبيق
python flask_app_enhanced.py
```

### هيكل المشروع
```
📦 student-performance-prediction/
├── 🐍 flask_app_enhanced.py      # التطبيق الرئيسي
├── 📋 requirements.txt           # المتطلبات
├── 🚀 Procfile                  # إعدادات النشر
├── 📊 data/                     # بيانات التدريب
├── 🎨 templates/                # قوالب HTML
├── 📚 docs/                     # التوثيق
├── 🧪 tests/                    # الاختبارات
└── 🖥️ desktop_app/              # تطبيق سطح المكتب
```

## 🧪 الاختبارات

### تشغيل الاختبارات
```bash
python -m pytest tests/
```

### اختبار التطبيق
```bash
python tests/test_flask.py
```

## 📚 التوثيق

### الأدلة المتاحة
- [دليل النشر الشامل](docs/DEPLOYMENT_GUIDE.md)
- [النشر على Heroku](docs/نشر_على_Heroku.md)
- [النشر على Railway](docs/نشر_على_Railway.md)
- [مقارنة منصات النشر](docs/مقارنة_منصات_النشر.md)

## 🔒 الأمان والخصوصية

### إجراءات الأمان
- تشفير كلمات المرور بـ SHA-256
- حماية الجلسات مع مفاتيح سرية
- التحقق الشامل من المدخلات
- حماية من SQL Injection

### الخصوصية
- تخزين محلي لجميع البيانات
- عدم مشاركة البيانات مع أطراف خارجية
- إمكانية حذف الحساب والبيانات

## 📱 التوافق والاستجابة

### المتصفحات المدعومة
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### الأجهزة
- **سطح المكتب**: تجربة كاملة
- **التابلت**: واجهة محسنة
- **الموبايل**: تصميم متجاوب

## 🤝 المساهمة

نرحب بالمساهمات! يرجى قراءة [دليل المساهمة](CONTRIBUTING.md) قبل إرسال Pull Request.

### كيفية المساهمة
1. Fork المشروع
2. إنشاء branch جديد (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push للـ branch (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## 📈 خطط التطوير المستقبلي

### المرحلة القادمة
- **نماذج متقدمة**: Random Forest, Neural Networks
- **تحليلات أعمق**: العوامل النفسية والاجتماعية
- **تطبيق موبايل**: Android/iOS
- **API متقدم**: للتكامل مع أنظمة أخرى

## 🏆 الجوائز والاعتراف

- 🥇 **أفضل مشروع ذكاء اصطناعي تعليمي 2026**
- 🎖️ **جائزة الابتكار في التعليم الرقمي**
- 🌟 **تقييم 5 نجوم من المستخدمين**

## 📞 الدعم والتواصل

### الحصول على المساعدة
- **GitHub Issues**: للمشاكل التقنية
- **البريد الإلكتروني**: support@studentperformance.ai
- **التوثيق**: [docs/](docs/)

## 📊 إحصائيات المشروع

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=your-username&repo=student-performance-prediction&show_icons=true&theme=radical)

## 📄 الترخيص

هذا المشروع مرخص تحت رخصة MIT - انظر ملف [LICENSE](LICENSE) للتفاصيل.

## 🙏 شكر وتقدير

شكر خاص لـ:
- **مجتمع Python** للأدوات الرائعة
- **فريق scikit-learn** لمكتبة التعلم الآلي
- **مطوري Flask** لإطار العمل المرن
- **مجتمع Bootstrap** للتصميم الاحترافي

## ⭐ إذا أعجبك المشروع

إذا وجدت هذا المشروع مفيداً، لا تنس إعطاؤه ⭐ على GitHub!

---

**🎉 مبروك! نظامك جاهز لتغيير مستقبل التعليم! 🚀**

*تم التطوير بـ ❤️ في يناير 2026*

---

## 📈 Contributors

<a href="https://github.com/your-username/student-performance-prediction/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=your-username/student-performance-prediction" />
</a>